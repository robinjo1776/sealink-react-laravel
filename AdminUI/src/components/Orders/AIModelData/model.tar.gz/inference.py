import joblib
import numpy as np
import json
import os

# Define the model loading function
def model_fn(model_dir):
    # Load the trained model from the SageMaker container's model directory
    model_path = os.path.join(model_dir, 'logistic_regression_model.joblib')
    model = joblib.load(model_path)
    return model

# Define the prediction function
def predict(input_data):
    # Assuming input_data is a dictionary containing a key 'features'
    input_array = np.array(input_data['features']).reshape(1, -1)
    prediction = model.predict(input_array)
    return prediction.tolist()  # Ensure the result is JSON serializable

# Define the input function (for preprocessing the request body)
def input_fn(request_body, content_type):
    if content_type == 'application/json':
        return json.loads(request_body)
    else:
        raise ValueError(f"Content type {content_type} not supported!")

# Define the output function (for formatting the prediction response)
def output_fn(prediction, accept):
    if accept == 'application/json':
        return json.dumps(prediction)
    else:
        raise ValueError(f"Accept type {accept} not supported!")
